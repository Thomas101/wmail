module.exports = Object.freeze({
	GOOGLE_CLIENT_ID 					: '712308738216-88c46pkl4d2gj20k7ko6khlsmh7p8v47.apps.googleusercontent.com',
	GOOGLE_CLIENT_SECRET			: 'CNppZr5rYFywJvkjyA4Sfz8E'
})