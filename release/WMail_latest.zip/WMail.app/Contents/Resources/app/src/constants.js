module.exports = Object.freeze({
	GITHUB_URL 								: 'https://github.com/Thomas101/wmail/',
	GITHUB_ISSUE_URL 					: 'https://github.com/Thomas101/wmail/issues',
	UPDATE_CHECK_URL 					: 'https://raw.githubusercontent.com/Thomas101/wmail/master/release/latest.json'
})